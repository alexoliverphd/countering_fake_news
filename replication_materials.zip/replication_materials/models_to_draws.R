#

library(tidyverse)
library(BART)

set.seed(101)

wd <- "/Users/alexoliver/Dropbox/replication_materials/"
setwd(wd)

#

# cf --> single row of a data frame with counterfactual values of variables, gives a single counterfactual
# CF --> multiple rows of a data frame with counterfactual values of variables, gives multiple counterfactuals (one per row)
# CFL --> multiple CFs

get_names <- function(CF) {

  names(CF) <- sub("i.", "", names(CF))

  for (i in 1:length(CF)) {
    CF[[i]] <- str_c(names(CF[i]), " = ", CF[[i]])
  }
  
   nam <- CF %>%
    unite(col = "cf", sep = " | ", remove = TRUE) %>%
    pull()
  
  return(nam)
}

make_cf <- function(D, cf) {
  
  x <- D %>% select(starts_with("i."))

  for (v in names(cf)) {
    x[[v]] <- cf[[v]]
  }
  
  return(x)
} 

make_CF <- function(D, CF) {
  
  X <- apply(CF, 1, function(z) make_cf(D, z))
  names(X) <- get_names(CF)
  
  return(X)
}

make_pr <- function(post, x0, x1 = NULL) {
  
  if(is.null(x1)) {
    
    p0 <- predict(post, x0)
    
    p <- apply(p0, 1, mean)
  } else {
    
    p0 <- predict(post, x0)
    p1 <- predict(post, x1)
    
    p <- apply(p1 - p0, 1, mean)
  }
  
  return(p)
}
make_PR <- function(post, X, base = NULL) {
  
  if(is.null(base)) {
    
    PR <- lapply(X, function(z) make_pr(post, x0 = z, x1 = NULL))
  } else {
    
    PR <- lapply(X, function(z) make_pr(post, x0 = X[[base]], x1 = z))
  }
  
  PR <- as.data.frame(PR)
  names(PR) <- names(X)
  
  return(PR)
}

draws_from_CF <- function(D, CF, post, base = NULL) {
  
  draws <- D %>%
    make_CF(CF) %>%
    make_PR(post, ., base) 
  
  if (is.null(base)) {
    ba <- names(draws)[1]
  } else {
    ba <- names(draws)[base]
  }
  
  draws <- draws %>%
    pivot_longer(everything()) %>%
    mutate(ba = ba) %>%
    select(name, value, ba)
  
  names(draws) <- c("cf", "pr", "ba")
  
  return(draws)
}
draws_from_CFL <- function(D, CFL, post, base = NULL) {
  
  draws <- CFL %>%
    map(~ draws_from_CF(D, ..1, post, base)) 

  draws <- draws %>%
    map2(names(CFL), ~ ..1 %>% mutate(gr = ..2) %>% select(gr, everything())) %>%
    bind_rows()
  
  return(draws)
}

#

D <- readRDS("data/data.Rds") 

Y <- c("o1", "o2", "o3", "o4", "o5", "o6")

i.condition <- c(0, 1, 2, 3)

CFL <- list(
  
  "g1" = data.frame(i.condition),
  
  "g2" = data.frame(i.condition, "i.trump" = 0),
  "g3" = data.frame(i.condition, "i.trump" = 1)
)

Y %>%
  map(~ readRDS(str_c("models/", ..1, ".Rds")) %>% 
        draws_from_CFL(D, CFL, ., base = NULL) %>%
        mutate(y = ..1) %>% 
        select(y, gr, cf, pr)) %>%
  bind_rows() %>%
  saveRDS("draws/levels.Rds")

Y %>%
  map(~ readRDS(str_c("models/", ..1, ".Rds")) %>% 
        draws_from_CFL(D, CFL, ., base = 1) %>%
        mutate(y = ..1) %>% 
        select(y, gr, cf, pr, ba)) %>%
  bind_rows() %>%
  saveRDS("draws/effects.Rds")

#

search_and_replace <- function(D, pattern, replacement) {
  
  D %>%
    mutate(across(where(is.character), str_replace_all, pattern = fixed(pattern), replacement = replacement))
}
search_and_replace_all <- function(D, patterns, replacements) {
  
  I <- length(patterns)
  
  for (i in 1:I) {
    D <- search_and_replace(D, patterns[i], replacements[i])
  }
  
  D
}
process_draws <- function(D, Y_lookup, CF_lookup) {
  
  n <- D$cf %>%
    str_count(fixed("|")) %>% 
    max()
  
  D <- D %>%
    separate(col = "cf", into = str_c("cf", 1:(n + 1)), sep = " \\| ", extra = "merge") 
  
  D <- D %>%
    search_and_replace_all(unname(Y_lookup), names(Y_lookup))
  D <- D %>%
    search_and_replace_all(unname(CF_lookup), names(CF_lookup))
  
  return(D)
}

Y_lookup <- c("There's an illegal immigration crisis at the southern border." = "o1", 
              "MS-13 is taking over the school." = "o2", 
              "City in Michigan first to fully implement Sharia law." = "o3",
              "Unbelievable: House Dems push America's first Sharia law." = "o4",
              "Black Lives Matter thugs blocking emergency crews from reaching Hurricane victims." = "o5",
              "The KKK has infiltrated police departments for years." = "o6")

CF_lookup <- c("Control" = "condition = 0", "MS-13" = "condition = 1", "Sharia" = "condition = 2", "BLM" = "condition = 3",
               "Anti-Trump" = "trump = 0", "Pro-Trump" = "trump = 1")

readRDS("draws/levels.Rds") %>%
  process_draws(Y_lookup, CF_lookup) %>%
  saveRDS("draws/processed_levels.Rds")

readRDS("draws/effects.Rds") %>%
  process_draws(Y_lookup, CF_lookup) %>%
  saveRDS("draws/processed_effects.Rds")

#
#