# 

library(tidyverse)

set.seed(101)

wd <- "/Users/alexoliver/Dropbox/replication_materials/"
setwd(wd)

rescale <- scales::number_format(scale = 100, accuracy = 0.1)

font <- "sans"
size <- 12

ggsave <- function(..., bg = 'white') ggplot2::ggsave(..., bg = bg)

#

L <- readRDS("draws/processed_levels.Rds") %>%
  replace_na(list(cf2 = "All")) %>%
  mutate(y = factor(y, levels = unique(y)),
         cf1 = factor(cf1, levels = unique(cf1)),
         cf2 = factor(cf2, levels = rev(c("All", "Anti-Trump", "Pro-Trump"))))

E <- readRDS("draws/processed_effects.Rds") %>%
  replace_na(list(cf2 = "All")) %>%
  mutate(y = factor(y, levels = unique(y)),
         cf1 = factor(cf1, levels = rev(unique(cf1))),
         cf2 = factor(cf2, levels = c("All", "Anti-Trump", "Pro-Trump")))

Y <- unique(E$y)

# 

e <- E %>%
  filter(cf1 != "Control") %>%
  group_by(y, cf1, cf2) %>%
  summarize(
    lb = quantile(pr, probs = 0.05),
    ce = mean(pr),
    ub = quantile(pr, probs = 0.95)
  ) 

plot_cate <- function(e, y_) {
  
  e %>%
    filter(y == y_) %>%
    ggplot(aes(x = cf1, y = ce)) +
    geom_hline(yintercept = 0, linetype = 3, color = "black") +
    geom_pointrange(aes(ymin = lb, ymax = ub)) +
    geom_label(aes(y = lb, label = rescale(lb)), size = 3.0, fill = "white", family = font, fontface = "plain", label.padding = unit(0.125, "lines")) +
    geom_label(aes(y = ub, label = rescale(ub)), size = 3.0, fill = "white", family = font, fontface = "plain", label.padding = unit(0.125, "lines")) +
    geom_label(aes(y = ce, label = rescale(ce)), size = 3.0, fill = "gray80", family = font, fontface = "bold", label.padding = unit(0.125, "lines")) +
    facet_wrap(~ cf2, ncol = 3) +
    scale_y_continuous(labels = rescale) +
    labs(subtitle = paste0("Conditional average treatment effect (CATE) on skepticism by subgroup and treatment\n"),
         title = unique(y_),
         y = "\nCATE (percentage point)",
         x = "Treatment\n",
         caption = "\n1,000 posterior draws of CATE generated from BART.\nMean of posterior draws is estimated CATE.\n5th percentile and 95th percentile of posterior draws form 90% credible interval."
    ) +
    theme_minimal() +
    theme(
      text = element_text(size = size, family = font),
      panel.grid.major.x = element_blank(),
      panel.grid.minor.x = element_blank(),
      #panel.grid.major.y = element_blank(),
      panel.grid.minor.y = element_blank(),
      plot.title = element_text(face = "bold"),
      axis.title = element_text(face = "bold"),
      strip.text = element_text(face = "bold")
    ) +
    #coord_cartesian(clip = 'off') +
    coord_flip(clip = "off")
  
  ggsave(filename = str_c(y_, ".png"), 
         path = "plots/",
         dpi = 320,
         units = "in",
         width = 8.5,
         height = 5.5)
}

Y %>%
  walk(~ plot_cate(e, ..1))

#

l <- L %>%
  filter(cf1 == "Control") %>%
  group_by(y, cf2) %>%
  summarize(
    lb = quantile(pr, probs = 0.05),
    ce = mean(pr),
    ub = quantile(pr, probs = 0.95)
  )

l %>%
  ggplot(aes(x = cf2, y = ce)) +
  geom_pointrange(aes(ymin = lb, ymax = ub)) +
  geom_label(aes(y = lb, label = rescale(lb)), size = 3.25, fill = "white", family = font, fontface = "plain", label.padding = unit(0.125, "lines")) +
  geom_label(aes(y = ub, label = rescale(ub)), size = 3.25, fill = "white", family = font, fontface = "plain", label.padding = unit(0.125, "lines")) +
  geom_label(aes(y = ce, label = rescale(ce)), size = 3.25, fill = "gray80", family = font, fontface = "bold", label.padding = unit(0.125, "lines")) +
  facet_wrap(~ y, ncol = 1) +
  scale_y_continuous(labels = rescale) +
  labs(subtitle = paste0("Baseline conditional average (BCA) skepticism by headline and subgroup\n"),
       title = "Skepticism without treatment",
       y = "\nBCA (percentage)\n",
       x = "Subgroup\n",
       caption = "\n1,000 posterior draws of BCA generated from BART.\nMean of posterior draws is estimated BCA.\n5th percentile and 95th percentile of posterior draws form 90% credible interval."
  ) +
  theme_minimal() +
  theme(
    text = element_text(size = size, family = font),
    panel.grid.major.x = element_blank(),
    panel.grid.minor.x = element_blank(),
    #panel.grid.major.y = element_blank(),
    panel.grid.minor.y = element_blank(),
    plot.title = element_text(face = "bold"),
    axis.title = element_text(face = "bold"),
    strip.text = element_text(face = "bold")
  ) +
  coord_cartesian(clip = 'off') +
  coord_flip()

ggsave(filename = "bca.png", 
       path = "plots/",
       dpi = 320,
       units = "in",
       width = 8.5,
       height = 11)

#
#