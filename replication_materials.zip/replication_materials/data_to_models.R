#

library(tidyverse)
library(BART)

set.seed(101)

wd <- "/Users/alexoliver/Dropbox/replication_materials/"
#wd <- "C:/Users/alexa/Dropbox/replication_materials/"
setwd(wd)

#



D <- readRDS("data/data.Rds") 

Y <- c("o1", "o2", "o3", "o4", "o5", "o6")

train_model <- function(D, y) {

  x.train <- D %>% select(starts_with("i."))
  y.train <- D %>% pull(str_c("d.", y))
  
  post <- wbart(
    x.train = x.train,
    y.train = y.train,
    nskip = 1000L,
    ndpost = 1000L
  )
  
  saveRDS(post, str_c("models/", y, ".Rds"))
}

Y %>%
  walk(~ train_model(D, ..1))

#